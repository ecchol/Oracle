#!/bin/sh
# $Header: stopvisionapps.sh $
#/*===========================================================================+
# |  Copyright (c) 2009 Oracle Corporation, Redwood Shores, California, USA   |
# |                        All rights reserved                                |
# |                       Applications  Division                              |
# +===========================================================================+
# |
# | FILENAME
# |   stopvisionapps.sh
# |
# | DESCRIPTION
# |   This script is run as part of Oracle E-Business Suite VM
# |   Template Configuration
# |
# |
# | LOCATION
# |
# | Usage:
# |
# | PLATFORM
# |   Unix Generic
# |
# |
# | HISTORY
# |     DATE     : Author   :  Description
# |     08/24/09 : Noby M Joseph
# |
# +===========================================================================+
#
# $AutoConfig$
#
# dbdrv: none


CURRENT_USER=`whoami`

if [ $CURRENT_USER != "oracle"  ]
then
   printf ""
    printf " This script can only be executed by the oracle user"
    printf " Please login as the oracle user and re-run this script";
    printf ""
    exit 1;
fi
# Source the Apps Environment file before starting the services

apps_src_pairs_file="/u01/install/APPS/scripts/inst_apps_pairs.txt"
APPS_BASE=`grep 's_base=' $apps_src_pairs_file | cut -d "=" -f2`
ORACLE_SID=`grep 's_dbSid' $apps_src_pairs_file | cut -d "=" -f2`
HOST_NAME=`grep 's_hostname' $apps_src_pairs_file | cut -d "=" -f2`
CONTEXT_NAME="${ORACLE_SID}_$HOST_NAME"

source ${APPS_BASE}/fs1/EBSapps/appl/APPS${CONTEXT_NAME}.env

if [ $FILE_EDITION != "patch" ]

then

echo "#############################################################################"
echo "##################### Execute SQL ECC scritps  ##################################"
ECC_DB_URL=jdbc:oracle:thin:@apps.example.com:1521:ebsdb
ECC_DB_CONNECTION=$(echo "$ECC_DB_URL" | sed "s|jdbc:oracle:thin:@\(.*\)|\1|" | sed "s|\(.*\):\(.*\)$|\1\/\2|")
public_ip=`curl -s ipinfo.io/ip`
my_ip=`sqlplus -s ECC_HOL/welcome1@$ECC_DB_CONNECTION <<EOF
set echo off
set feedback off
set heading off
set pages 0
select HOST from ECC_SOURCE_SYSTEM  ; 
exit;
EOF`
if test "$public_ip" = "$my_ip"
then
echo "ip is configured"
else
sqlplus /nolog <<EOF
connect ECC_HOL/"welcome1"@"$ECC_DB_CONNECTION"
set head off 
set verify off 
set feedback off 
set pages 0 
set echo on 
update ECC_SOURCE_SYSTEM set HOST = '$public_ip' where PORT = '8000' ;
exit
EOF
fi

fi