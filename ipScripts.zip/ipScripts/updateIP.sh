#!/bin/sh
TS=$(date +'%s')
LOG=/tmp/boot_${TS}.log
echo "Last reboot time: $(date)" | tee -a $LOG
whoami

sudo -i -u cp adautohol.sh /u01/install/APPS/scripts/adautohol.sh
sudo -i -u cp sourceEccSystem.sh /u01/install/APPS/scripts/sourceEccSystem.sh

######### Adding IP to login via IP ######################
CONTEXT_FILE="/u01/install/APPS/fs1/inst/apps/ebsdb_apps/appl/admin/ebsdb_apps.xml"
public_ip=`curl -s ipinfo.io/ip` 
source /u01/install/APPS/EBSapps.env run
if sudo grep -q "$public_ip" $CONTEXT_FILE ;
then 
echo "Login with IP changes already exsist" | tee -a $LOG
############Restarting services###########################
echo -e "Starting Database ........ " | tee -a $LOG
sudo -i -u oracle /u01/install/APPS/scripts/startdb.sh
if [ $? = 0 ];then
echo -e "Database Started" | tee -a $LOG
fi
echo -e "Starting up EBSAPPS ...." | tee -a $LOG
sudo -i -u oracle /u01/install/APPS/scripts/startapps.sh
x=1
status_code=0
while :
do
ps -ef|grep  "/opmn/bin/opmn -d"|grep -v "grep" >/dev/null 2>&1
opmn=$?
ps -ef|grep "bin/httpd.worker"|grep -v "grep" >/dev/null 2>&1
httpd=$?
if [ "$opmn" -eq 0 ]   && [ "$httpd" -eq 0 ] ;then
        echo -e "OPMN and HTTPD started Successfully\n" | tee -a $LOG
        echo -e "EBS APPS are up and running \n" | tee -a $LOG
        break
fi
sleep 1
x=$(( $x + 1 ))
if [ "$opmn" -eq 1 ]  || [ "$httpd" -eq 1 ] ;then
        if [ "$opmn" -eq 1 ] ;then
        echo -e "OPMN  not running\n" | tee -a $LOG
        fi
        if [ "$httpd" -eq 1 ] ;then
        echo -e "HTTPD not running\n" | tee -a $LOG
        fi
        echo -e "EBS apps not running | tee -a $LOG"
break
fi
if [ $x -eq 300  ]
then
        echo -e "OPMN and HTTPD  are taking much time to start?" | tee -a $LOG
        break
fi
done
else 
echo "Performing Login with IP Chnages" | tee -a $LOG
sudo  sed -i -e "s|<externURL oa_var=\"s_external_url\">[^<]*</externURL>|<externURL oa_var=\"s_external_url\">http://$public_ip:8000/OA_HTML/AppsLogin</externURL>|g" $CONTEXT_FILE

sudo sed -i -e "s|<webentrydomain oa_var=\"s_webentrydomain\">[^<]*</webentrydomain>|<webentrydomain oa_var=\"s_webentrydomain\"></webentrydomain>|g" $CONTEXT_FILE
sudo sed -i -e "s|<webentryhost oa_var=\"s_webentryhost\">[^<]*</webentryhost>|<webentryhost oa_var=\"s_webentryhost\">$public_ip</webentryhost>|g" $CONTEXT_FILE
sudo sed -i -e "s|<login_page oa_var=\"s_login_page\">[^<]*</login_page>|<login_page oa_var=\"s_login_page\">http://$public_ip:8000/OA_HTML/AppsLogin</login_page>|g" $CONTEXT_FILE
echo -e "Starting Database ........ " | tee -a $LOG
sudo -i -u oracle /u01/install/APPS/scripts/startdb.sh
if [ $? = 0 ];then
echo -e "Database Started" | tee -a $LOG
fi
sudo -i -u  oracle /u01/install/APPS/scripts/sourceEccSystem.sh 
if [ $? = 0 ];then
echo -e "sourceEccSystem Started" | tee -a $LOG
fi
echo -e "Running adautoconfig" | tee -a $LOG
sudo -i -u oracle /u01/install/APPS/scripts/adautohol.sh
if [ $? = 0 ];then
echo -e "adautoconfig Ran successfully" | tee -a $LOG
fi
echo -e "Stop  EBSAPPS ...." | tee -a $LOG
sudo -i -u oracle /u01/install/APPS/scripts/stopapps.sh
if [ $? = 0 ];then
echo -e "ebs apps  stopped successfully" | tee -a $LOG
fi
echo -e "Starting up EBSAPPS ...." | tee -a $LOG
sudo -i -u oracle /u01/install/APPS/scripts/startapps.sh
x=1
status_code=0
while :
do
ps -ef|grep  "/opmn/bin/opmn -d"|grep -v "grep" >/dev/null 2>&1
opmn=$?
ps -ef|grep "bin/httpd.worker"|grep -v "grep" >/dev/null 2>&1
httpd=$?
if [ "$opmn" -eq 0 ]   && [ "$httpd" -eq 0 ] ;then
        echo -e "OPMN and HTTPD started Successfully\n" | tee -a $LOG
        echo -e "EBS APPS are up and running \n" | tee -a $LOG
        break
fi
sleep 1
x=$(( $x + 1 ))
if [ "$opmn" -eq 1 ]  || [ "$httpd" -eq 1 ] ;then
        if [ "$opmn" -eq 1 ] ;then
        echo -e "OPMN  not running\n" | tee -a $LOG
        fi
        if [ "$httpd" -eq 1 ] ;then
        echo -e "HTTPD not running\n" | tee -a $LOG
        fi
        echo -e "EBS apps not running | tee -a $LOG"
break
fi
if [ $x -eq 300  ]
then
        echo -e "OPMN and HTTPD  are taking much time to start?" | tee -a $LOG
        break
fi
done

fi

echo -e "Starting VNC Server" | tee -a $LOG
sudo systemctl start vncserver_oracle@:1.service
if [ $? = 0 ];
then
echo -e "VNC server started" | tee -a $LOG
fi

echo -e "Starting VNC Server" | tee -a $LOG
sudo systemctl start vncserver_oracle@:1.service
if [ $? = 0 ];
then
echo -e "VNC server started" | tee -a $LOG
fi