#!/bin/sh
# $Header: aduatohol.sh $
#/*===========================================================================+
# |  Copyright (c) 2009 Oracle Corporation, Redwood Shores, California, USA   |
# |                        All rights reserved                                |
# |                       Applications  Division                              |
# +===========================================================================+
# |
# | FILENAME
# |   startapps.sh
# |
# | DESCRIPTION
# |   This script is run as part of Oracle E-Business Suite VM
# |   Template Configuration
# |
# |
# | LOCATION
# |
# | Usage:
# |
# | PLATFORM
# |   Unix Generic
# |
# |
# | HISTORY
# |     DATE     : Author   :  Description
# |     08/24/09 : Noby M Joseph
# |
# +===========================================================================+
#
# $AutoConfig$
#
# dbdrv: none


#
# Check if the user running the config script is the root user
#

CURRENT_USER=`whoami`

if [ $CURRENT_USER != "oracle"  ]
then
printf ""
    printf " This script can only be executed by the oracle user"
    printf " Please login as the oracle user and re-run this script";
    printf ""
    exit 1;
fi


# Source the Apps Environment file before starting the services

apps_src_pairs_file="/u01/install/APPS/scripts/inst_apps_pairs.txt"
APPS_BASE=`grep 's_base=' $apps_src_pairs_file | cut -d "=" -f2`
ORACLE_SID=`grep 's_dbSid' $apps_src_pairs_file | cut -d "=" -f2`
HOST_NAME=`grep 's_hostname' $apps_src_pairs_file | cut -d "=" -f2`
CONTEXT_NAME="${ORACLE_SID}_$HOST_NAME"

if  [ -f ${APPS_BASE}/fs1/EBSapps/appl/APPS${CONTEXT_NAME}.env ]; then
    source ${APPS_BASE}/fs1/EBSapps/appl/APPS${CONTEXT_NAME}.env
fi
   rm /u01/install/APPS/scripts/.acdone 
    printf "\n"
    printf "\n=================================================="
    printf "\n Running autoconfig as part of boot"
    printf "\n=================================================="
    printf "\n"
    sh $INST_TOP/admin/scripts/adautocfg.sh appspass=apps
    touch /u01/install/APPS/scripts/.acdone
